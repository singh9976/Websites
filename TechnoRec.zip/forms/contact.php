<?php
  $name= $_REQUEST['name'];
  $email=$_REQUEST['email'];
  $message=$_REQUEST['message'];

  if (empty($name) || empty($email) || empty($message)){
    echo "Please fill all the fields";
  }
  else{
    mail("parmindersingh996@gmail.com", "TechnoRec Contact US", $message , "From: $name <$email>");
    echo"<script type='text/javascript'alert('your message sent successfully')>
    windpow.history.log(-1);
    </script>";
  }
?>
