<?php
    $conn = mysqli_connect('localhost', 'participate', 'usercheck', 'Participant');
    if(!$conn){
        die("Connection Failed:".mysqli_connect_error());
    }
    if(isset($_POST["submit3000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/men-bodybuilding");
    }elseif(isset($_POST["submit3500"])){
         $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/men-physique");
    }elseif(isset($_POST["submit4000"])){
         $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/male-fitness-and-fashion-model");
    }elseif(isset($_POST["submit6500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/men-bodybuilding-and-physique");
    }elseif(isset($_POST["submit7000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/male-ff-and-bodybuilding");
    }elseif(isset($_POST["submit7500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/male-ff-andphysique");
    }elseif(isset($_POST["submit10500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/body-physique-and-fashion");
    }elseif(isset($_POST["submit2nd3500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/mens-classic");
    }elseif(isset($_POST["submit2nd6500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/bodybuilding-and-classic");
    }elseif(isset($_POST["submit2nd7000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/physique-and-classic");
    }elseif(isset($_POST["submit2nd7500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/fashion-and-classic");
    }elseif(isset($_POST["submit2nd10000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/body-and-physique-and-classic");
    }elseif(isset($_POST["submit2nd10500"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/body-and-fashion-and-classic");
    }elseif(isset($_POST["submit2nd11000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/physique-fashion-and-classic");
    }elseif(isset($_POST["submit2nd14000"])){
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Physique`, `Bodybuilding`, `Fitness & Fashion Model`, `Classic`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["height"]."', '".$_POST["weight"]."', '".$_POST['mff']."', '".$_POST["mc"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/all-category");
    }elseif(isset($_POST["submitf3500"])){
        $sql = "INSERT INTO `Females`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Bodybuilding`, `Female Fashion Model`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["bodybuilding"]."', '".$_POST["fashion"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/female-fitness-bodybuilding");
    }elseif(isset($_POST["submitf4000"])){
        $sql = "INSERT INTO `Females`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Bodybuilding`, `Female Fashion Model`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["bodybuilding"]."', '".$_POST["fashion"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/femalefitness-and-fashionmodel");
    }elseif(isset($_POST["submitf7500"])){
        $sql = "INSERT INTO `Females`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Bodybuilding`, `Female Fashion Model`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '".$_POST["aadhar"]."', '".$_POST["bodybuilding"]."', '".$_POST["fashion"]."')";
        mysqli_query($conn, $sql);
        header("Location: https://rzp.io/l/female-all-category");
    }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="assets/img/favicon.ico" rel="icon">
    <title>Registration!</title>
    <link rel="stylesheet" type="text/css" href="assets/css/Reg&Buy.css">
    
  </head>
  <body>
     <p><a id="logo"><img alt="" src="logo1.png" /></a></p>
    <div class="container">
      
  <section>
    <div class="container-fluid">
      <form method="post">
              <h1>Register To Participate</h1>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText ">First Name</div>
                    <input type="text" required="" name="firstname" class="input">
                  </div>
                </div>  
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">Last Name</div>
                    <input type="text" required="" name="lastname" class="input">
                  </div>
                </div>  
              </div>

              <div class="form-row">
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">Email</div>
                    <input type="email" id="email" required="" name="email" class="input">
                  </div>
                </div>  
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">Mobile</div>
                    <input type="text" pattern="[1-9]{1}[0-9]{9}" required="" name="contact" class="input" id="mobile">
                  </div>
                </div>
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">Aadhar Number</div>
                    <input type="text" required="" name="aadhar" class="input" id = "AN">
                  </div>
                </div>
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">Date Of Birth</div>
                    <input type="text" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" id="dob" required="" name="" class="input">
                  </div>
                </div>
                
              </div>
              <div class="form-row">
                <div class="form-group col-md-12">
                  <div class="inputBox">
                    <div class="inputText">Address</div>
                    <input type="text" required="" name="address" class="input">
                  </div>
                </div>  
              </div>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">City</div>
                    <input type="text" required="" name="" class="input">
                  </div>
                </div>  
                <div class="form-group col-md-6">
                  <div class="inputBox">
                    <div class="inputText">State</div>
                    <input type="text"  required="" name="" class="input" id="">
                  </div>
                </div>  
              </div>
              <div class="form-row">
                
                <div class="form-group col-md-6 inputBox">
                  <div class="col-md-6 row radioText">
                    <label class="gndr">Gender</label>
                    <div class="row">
                        <div class="">
                            <div class=" custom-control custom-radio">
                                <input class=" gndradio custom-control-input" id="male" type="radio" name="reg_gender" value="Male">
                                <label class="gndroptn custom-control-label" for="male">Male</label>&nbsp &nbsp &nbsp
                            </div>
                        </div>
                        <div class="">
                            <div class="contact3-form-radio custom-control custom-radio">
                                <input class="gndradio custom-control-input" id="female" type="radio" name="reg_gender" value="Female">
                                <label class="gndroptn custom-control-label" for="female">Female</label>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
              </div>
              <div class="form-row" id="menctgry">
                <div class="ctgrylbl">Categories (Select at least One Category)</div>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#malehome" role="tab" aria-controls="home" aria-selected="true">General</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#maleprofile" role="tab" aria-controls="profile" aria-selected="false">Specially Abled</a>
                  </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="malehome" role="tabpanel" aria-labelledby="home-tab">
                    <div class="mb form-row">
                      <div class="form-group col-md-6">
                        <div class="mbb">Men's Open Bodybuilding(Fee- 3000/-)</div>
                        <div class="custom-control custom-radio">
                          <input type="radio" id="mb1" name="weight" value="0 to 60 Kgs" class="custom-control-input romb">
                          <label class="custom-control-label ctgrytxt" for="mb1">0 to 60 Kgs</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="mb2" name="weight" value="60-65 Kgs" class="custom-control-input romb">
                            <label class="custom-control-label ctgrytxt" for="mb2">60-65 Kgs</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="mb3" name="weight" value="65-70 Kgs" class="custom-control-input romb">
                            <label class="custom-control-label ctgrytxt" for="mb3">65-70 Kgs</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="mb4" name="weight" value="70-75 Kgs" class="custom-control-input romb">
                            <label class="custom-control-label ctgrytxt" for="mb4">70-75 Kgs</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="mb5" name="weight" value="75 Kgs & Above" class="custom-control-input romb">
                            <label class="custom-control-label ctgrytxt " for="mb5">75 Kgs & Above</label>
                        </div>
                        <input type="button" class=" unselect" id="unselect1" name="" value="Unselect">
                      </div>
                      <div class="form-group col-md-6">
                        <div class="mbb">Men's Physique(Fee- 3500/-)</div>
                        <div class="custom-control custom-radio">
                          <input type="radio"  id="mf1" name="height" value="Below 170 cms" class="custom-control-input romf">
                          <label class="custom-control-label ctgrytxt " for="mf1">Below 170 cms</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="mf2" name="height" value="Above 170 cms" class="custom-control-input romf">
                            <label class="custom-control-label ctgrytxt" for="mf2">Above 170 cms</label>
                        </div>
                        <input type="button" class=" unselect" id="unselect2" name="" value="Unselect">
                      </div>
                      <div class="form-group col-md-6">
                        <div class="mbb">Male Fitness & Fashion Model(Fee- 4000/-)</div>
                        <div class="custom-control custom-radio">
                          <input type="radio" value = "Yes"  id="mff" name="mff" class="custom-control-input romff">
                          <label class="custom-control-label ctgrytxt " for="mff">Fitness + Fashion(Open Class)</label>
                        </div>
                        <input type="button" class=" unselect" id="unselect4" name="" value="Unselect">
                      </div>
                      <div class="form-group col-md-6">
                        <div class="mbb">Men's Classic(Fee- 3500/-)</div>
                        <div class="custom-control custom-radio">
                          <input type="radio" value = "Upto 5.8 & 75 Kgs"  id="mc1" name="mc" class="custom-control-input romc">
                          <label class="custom-control-label ctgrytxt " for="mc1">Upto 5.8 & 75 Kgs</label>
                        </div>
                        <div class="custom-control custom-radio">
                          <input type="radio" value = "Above 5.8 & 75 Kgs"  id="mc2" name="mc" class="custom-control-input romc">
                          <label class="custom-control-label ctgrytxt " for="mc2">Above 5.8 & 75 Kgs</label>
                        </div>
                        <input type="button" class=" unselect" id="unselect6" name="" value="Unselect">
                      </div>
                    </div>
                    <div class="form-row">
                      <div class="col-md-6">
                        <input type="submit" name="submit3000" id="pay3000" formaction="" value="Register & Pay(3,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit3500" id="pay3500" formaction="" value="Register & Pay(3,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit6500" id="pay6500" formaction="" value="Register & Pay(5,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit4000" id="pay4000" formaction="" value="Register & Pay(4,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit7000" id="pay7000" formaction="" value="Register & Pay(6,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit7500" id="pay7500" formaction="" value="Register & Pay(6,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit10500" id="pay10500" formaction="" value="Register & Pay(9,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd3500" id="pay2nd3500" formaction="" value="Register & Pay(3,500/-)" class="btn button btn-outline-warning"> 
                        <input type="submit" name="submit2nd6500" id="pay2nd6500" formaction="" value="Register & Pay(5,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd7000" id="pay2nd7000" formaction="" value="Register & Pay(6,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd7500" id="pay2nd7500" formaction="" value="Register & Pay(6,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd10000" id="pay2nd10000" formaction="" value="Register & Pay(8,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd10500" id="pay2nd10500" formaction="" value="Register & Pay(9,000/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd11000" id="pay2nd11000" formaction="" value="Register & Pay(10,500/-)" class="btn button btn-outline-warning">
                        <input type="submit" name="submit2nd14000" id="pay2nd14000" formaction="" value="Register & Pay(12,000/-)" class="btn button btn-outline-warning">
                      </div>  
                    </div>
                  </div>
                  <div class="tab-pane fade" id="maleprofile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="mb form-row ">
                      <div class="form-group">
                        <div class="mbb">Open Category(Free)</div>
                        <div class="ctgrytxt">For Registration Contact Here:-<br>
                          WhatsApp:- 9829333374 <br>   
                          Email: mrandmsdiamond@gmail.com <br>
                        </div>
                        ** You Must have an Obvious and Clear Disability. If You don't have an Obvious and clear Disability, then You Must bring a Doctor's Certificate Stating your Disability. This Certificate <b>MUST BE ATTESTED BY A GOVERNMENT OFFICIAL.</b>
                      </div>
                    </div>
                    
                  </div>
                </div>
              </div>
              <div class="form-row" id="femalectgry">
                <div class="ctgrylbl">Categories (Select at least One Category)</div>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active " id="home-tab" data-toggle="tab" href="#femalehome" role="tab" aria-controls="home" aria-selected="true">General</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link " id="profile-tab" data-toggle="tab" href="#femaleprofile" role="tab" aria-controls="profile" aria-selected="false">Specially Abled</a>
                      </li>
                      
                    </ul>
                    <div class="tab-content" id="myTabContent">
                      <div class="tab-pane fade show active" id="femalehome" role="tabpanel" aria-labelledby="home-tab">
                        <div class="form-row mb ">
                          <div class="form-group col-md-6">
                            <div class="mbb">Female Fitness (Bikini)(Fee- 3500/-)</div>
                            <div class="custom-control custom-radio" id="ffmradio">
                              <input type="radio" name = "bodybuilding" value = "Yes"  class="custom-control-input"  id="ffm">
                              <label class="custom-control-label moc" for="ffm">Open Class</label>
                            </div>
                            <input type="button" class=" unselect" id="unselect3" name="" value="Unselect">
                          </div>
                          <div class="form-group col-md-6">
                            <div class="mbb">Female Fitness & Fashion Model(Fee- 4000/-)</div>
                            <div class="custom-control custom-radio" id="ffmradio">
                              <input type="radio"  name = "fashion" value = "Yes"  class="custom-control-input" id="fffm">
                              <label class="custom-control-label moc" for="fffm">Open Class(Fitness + Fashion)</label>
                            </div>
                            <input type="button" class=" unselect" id="unselect5" name="" value="Unselect">
                          </div>
                        </div>
                        <div class="form-row">
                          <div class="col-md-6">
                            <input type="submit" name="submitf3500" id="pay4" formaction="" value="Register & Pay(3,500/-)" class="btn button btn-outline-warning">
                            <input type="submit" name="submitf4000" id="pay1" formaction="" value="Register & Pay(4,000/-)" class="btn button btn-outline-warning">
                            <input type="submit" name="submitf7500" id="pay2" formaction="" value="Register & Pay(6,500/-)" class="btn button btn-outline-warning">
                          </div>  
                        </div>
                      </div>
                      <div class="tab-pane fade" id="femaleprofile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="mb form-row ">
                          <div class="form-group">
                            <div class="mbb">Open Category(Free)</div>
                            <div class="ctgrytxt">For Registration Contact Here:-<br>
                              WhatsApp:- 9829333374 <br>   
                              Email: mrandmsdiamond@gmail.com
                            </div>
                            ** You Must have an Obvious and Clear Disability. If You don't have an Obvious and clear Disability, then You Must bring a Doctor's Certificate Stating your Disability. This Certificate <b>MUST BE ATTESTED BY A GOVERNMENT OFFICIAL.</b>
                          </div>
                        </div>  
                      </div>
                    </div>
              </div>  
          </form>
        </div>
      </div>
    </div>
  </section>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="assets/js/Reg.js"></script>
    
  </body>
</html>