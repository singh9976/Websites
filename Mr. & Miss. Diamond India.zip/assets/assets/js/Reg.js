$(".input").focus(function(){
        $(this).parent().addClass("focus");
      }).blur(function(){
        if($(this).val() === ''){
        $(this).parent().removeClass("focus");
        $(this).attr("placeholder", "")
        }
      });
      $("#mobile").focus(function(){
          $(this).attr("placeholder", "Ex. 0123456789")
      });
      $("#dob").focus(function(){
        $(this).attr("placeholder", "DD-MM-YYYY")
      });
      $("#email").focus(function(){
        $(this).attr("placeholder", "EX. abc@def.com")
      });
$("#male").change(function(){
        $("#menctgry").fadeIn("slow");
        $("#femalectgry").css("display", "none");
      });
      $("#female").click(function(){
        $("#femalectgry").fadeIn("slow");
        $("#menctgry").css("display", "none")
      });
      $("#unselect3").click(function(){
        $("#ffm").prop("checked", false);
      }); 
      $(".romb").change(function(){
        $("#pay3000").css("display", "block");
        if($("#mf1").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd14000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
        }else if($("#mf1").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mff").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mf1").prop("checked") && $("#mff").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked")){
          $("#pay10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mff").prop("checked")){
          $("#pay7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }
      });
      $("#unselect1").click(function(){
        $(".romb").prop("checked", false);
        if($(".romb").prop("checked", false)){
          $("#pay3000").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd14000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
        };
        if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mff").prop("checked")){
          $("#pay4000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") && $("#mff").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked")){
          $("#pay7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mc1").prop("checked") && $("#mff").prop("checked") || $("#mc2").prop("checked") && $("#mff").prop("checked")){
          $("#pay2nd7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd11000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
      });
      $(".romf").change(function(){
        $("#pay3500").css("display", "block");
        if($("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked")){
           $("#pay2nd14000").css("display", "block");
           $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
        }else if($("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mff").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd11000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mff").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked")){
          $("#pay10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mff").prop("checked")){
          $("#pay7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }
      });
      $("#unselect2").click(function(){
        $(".romf").prop("checked", false);
        if($(".romf").prop("checked", false)){
          $("#pay3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay3000").css("display", "block");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mff").prop("checked")){
          $("#pay4000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mff").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked")){
          $("#pay7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mff").prop("checked") && $("#mc2").prop("checked") ){
          $("#pay2nd7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");       
        };
        if($("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");   
        };
      });
      $(".romff").change(function(){
        $("#pay4000").css("display", "block");
        if($("#mb1").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")   
          || $("#mb4").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")  
          || $("#mb5").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd14000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mf2").prop("checked")){
          $("#pay10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mf1").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd11000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }
      });
      $("#unselect4").click(function(){
        $(".romff").prop("checked", false);
        if($(".romff").prop("checked", false)){
          $("#pay4000").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
        };
        if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay3000").css("display", "block");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mc1").prop("checked") || $("#mc2").prop("checked")){
          $("#pay2nd3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mf2").prop("checked")){
          $("#pay6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mc1").prop("checked") || $("#mb1").prop("checked") && $("#mc2").prop("checked") || $("#mb2").prop("checked") && $("#mc1").prop("checked") || $("#mb2").prop("checked") && $("#mc2").prop("checked") || $("#mb3").prop("checked") && $("#mc1").prop("checked") || $("#mb3").prop("checked") && $("#mc2").prop("checked") || $("#mb4").prop("checked") && $("#mc1").prop("checked") || $("#mb4").prop("checked") && $("#mc2").prop("checked") || $("#mb5").prop("checked") && $("#mc1").prop("checked") || $("#mb5").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") && $("#mc1").prop("checked") || $("#mf1").prop("checked") && $("#mc2").prop("checked") || $("#mf2").prop("checked") && $("#mc1").prop("checked") || $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");       
        };
        if($("#mb1").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb1").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb2").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb3").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")   
          || $("#mb4").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb4").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")  
          || $("#mb5").prop("checked") && $("#mf1").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf1").prop("checked") && $("#mc2").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf2").prop("checked") && $("#mc1").prop("checked") 
          || $("#mb5").prop("checked") && $("#mf2").prop("checked") && $("#mc2").prop("checked")){
          $("#pay2nd10000").css("display", 'block');
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
      });
      $(".romc").change(function(){
        $("#pay2nd3500").css("display", "block");
        if($("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked")){
          $("#pay2nd14000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mf2").prop("checked")){
          $("#pay2nd10000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") && $("#mff").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked")){
          $("#pay2nd10500").css("display", "block"); 
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");        
        }else if($("#mf1").prop("checked") && $("#mff").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked")){
          $("#pay2nd11000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay2nd6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay2nd7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }else if($("#mff").prop("checked")){
          $("#pay2nd7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        }
      });
      $("#unselect6").click(function(){
        $(".romc").prop("checked", false);
        if($(".romc").prop("checked", false)){
          $("#pay2nd3500").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") || $("#mb2").prop("checked") || $("#mb3").prop("checked") || $("#mb4").prop("checked") || $("#mb5").prop("checked")){
          $("#pay3000").css("display", "block");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") || $("#mf2").prop("checked")){
          $("#pay3500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mff").prop("checked")){
          $("#pay4000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mf2").prop("checked")){
          $("#pay6500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mff").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked")){
          $("#pay7000").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mf1").prop("checked") && $("#mff").prop("checked") || $("#mf2").prop("checked") && $("#mff").prop("checked")){
          $("#pay7500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay10500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
        if($("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb1").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb2").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb3").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb4").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mf1").prop("checked") || $("#mb5").prop("checked") && $("#mff").prop("checked") && $("#mf2").prop("checked")){
          $("#pay10500").css("display", "block");
          $("#pay3000").css("display", "none");
          $("#pay3500").css("display", "none");
          $("#pay4000").css("display", "none");
          $("#pay2nd3500").css("display", "none");
          $("#pay6500").css("display", "none");
          $("#pay7000").css("display", "none");
          $("#pay2nd6500").css("display", "none");
          $("#pay7500").css("display", "none");
          $("#pay2nd7000").css("display", "none");
          $("#pay2nd7500").css("display", "none");
          $("#pay2nd10000").css("display", "none");
          $("#pay2nd10500").css("display", "none");
          $("#pay2nd11000").css("display", "none");
          $("#pay2nd14000").css("display", "none");
        };
      });
      $("#menoc").change(function(){
        $("#pay").css("display", "block")
      });
      $("#unselectmenoc").click(function(){
        $("#menoc").prop("checked", false);
        $("#pay").css("display", "none");
      });
      $("#ffm").change(function(){
        $("#pay4").css("display", "block");
        if($("#fffm").prop("checked")){
          $("#pay2").css("display", "block");
          $("#pay4").css("display", "none");
          $("#pay1").css("display", "none");
        }
      });
      $("#unselect3").click(function(){
        $("#ffm").prop("checked", false);
        $("#pay4").css("display", "none");
        if($("#fffm").prop("checked")){
          $("#pay1").css("display", "block");
          $("#pay2").css("display", "none");
        }
      });
      $("#fffm").change(function(){
        $("#pay1").css("display", "block");
        if($("#ffm").prop("checked")){
          $("#pay2").css("display", "block");
          $("#pay1").css("display", "none");
          $("#pay4").css("display", "none")
        }
      });
      $("#unselect5").click(function(){
        $("#fffm").prop("checked", false);
        $("#pay1").css("display", "none");
        if($("#ffm").prop("checked")){
          $("#pay4").css("display", "block");
          $("#pay2").css("display", "none")
        }
      });
      $("#oc").change(function(){
        $("#pay5").css("display", "block")
      });
      $("#unselectoc").click(function(){
        $("#oc").prop("checked", false);
        $("#pay5").css("display", "none");
      });