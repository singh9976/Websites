<?php
    $conn = mysqli_connect('localhost', 'participate', 'usercheck', 'Participant');
    if(!$conn){
        echo "not connected";
    }else{
        echo "connected";
    }
    
    if(isset($_POST['save'])){
        $gender = $_POST['sex'];
        $sql = "INSERT INTO `Participants`(`First Name`, `Last Name`, `Contact`, `Email`, `Aadhar`, `Height`, `Weight`) VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["contact"]."', '".$_POST["email"]."', '2345', '$gender', '4')";
    mysqli_query($conn, $sql);
    }
?>
<html>
    <body>
        <form method="post"> 
            <label id="first"> First Name:</label><br/>
            <input type="text" name="firstname"><br/>
        
            <label id="first">Last Name</label><br/>
            <input type="text" name="lastname"><br/>
            
            <label id="first">Contact</label><br/>
            <input type="text" name="contact"><br/>
        
            <label id="first">Email</label><br/>
            <input type="email" name="email"><br/>
            
            <input type="radio" name="sex" value="Male">Male
            <input type="radio" name="sex" value="Female">Male
            
            <button type="submit" name="save">save</button>
            
        </form>
    </body>
</html>